function Nav() {
    return (
        <div className='nav'>
            <div className="navbar">
                <div className='logo'>Seungyeon's space</div>
                <div className="navbarR">
                    <div>about</div>
                    <div>project</div>
                    <div>contact</div>
                </div>
            </div>
        </div>
    )
}

export default Nav;