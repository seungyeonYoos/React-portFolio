function Contact (){
    return (
        <div className="contactComponent">
            <div className="contact-h1">
                <div>CONTACT</div>
            </div>
        </div>
    )
}

export default Contact;